function progress()
{
    printf -- "$1\n$2" > ~/.ed_progress
}
